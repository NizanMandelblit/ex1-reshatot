import socket
import sys
import time

timePassed = time.clock()  # time in seconds to check the TTL
myPort = sys.argv[1]
parentIP = sys.argv[2]
parentPort = sys.argv[3]
ipsFileName = sys.argv[4]  # the cache file

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind(('', 12345))

start_time = time.time()
time.sleep(1)
elapsed_time = int(time.time() - start_time)
print(elapsed_time)
time.sleep(1)
elapsed_time = int(time.time() - start_time)
print(elapsed_time)
time.sleep(1)
elapsed_time = time.time() - start_time
print(elapsed_time)
time.sleep(1)
elapsed_time = time.time() - start_time
print(elapsed_time)
time.sleep(1)
elapsed_time = time.time() - start_time
print(elapsed_time)

#print(time.strftime("%H:%M:%S", time.gmtime(elapsed_time)))




# while True:
# 	f = open(ipsFileName, "a+")
# 	ipRequest, addrClient = s.recvfrom(1024)
# 	retIp=None
# 	#checking the cache of the server
# 	for x in f:
# 		lineSplit=x.split(",")
# 		if ipRequest.decode()==lineSplit[0]:
# 			retIp=lineSplit[1]
# 	#asking the parent server if its not found in the cache file
# 	if retIp==None:
# 		s.sendto(ipRequest,(parentIP,int(parentPort)))
# 		retLine,addrParentServer=s.recvfrom(1024)
# 		splitedLine=retLine.decode().split(",")
# 		retIp=splitedLine[1]
# 		f.write('\n'+retLine.decode())
# 		f.close()
# 	s.sendto(retIp.encode(), addrClient)
#
#
# f.close()
# s.close()
