import socket
import sys


myPort=sys.argv[1]
parentIP=sys.argv[2]
parentPort=sys.argv[3]
ipsFileName=sys.argv[4]



s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) 
s.bind(('', 12345))

while True:
	data, addr = s.recvfrom(1024)
	print(str(data), addr)
	s.sendto(data.upper(), addr)
